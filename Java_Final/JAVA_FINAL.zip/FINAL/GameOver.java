package com.huaxin.enery;

import java.awt.*;
import java.awt.Image;
public class GameOver extends  Enery{
    public GameOver(int x, int y, int width, int height, Image img) {
        super(x, y, width, height, img);
    }
}
