package com.huaxin.mario;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import com.huaxin.enery.Enery;
import com.huaxin.enery.GameOver;
import com.huaxin.enery.Pipe;
import com.huaxin.enery.Block;
import com.huaxin.enery.Win;
import Util.Map;
public class GameFrame extends JFrame{
    public Mario mario;
    public Enery pipe,Block,mushroom;
    public ArrayList<Enery> eneryList = new ArrayList<Enery>();
    public int [][] map =null;
    public GameFrame() throws Exception {
        mario = new Mario(this);
        mario.start();
        Map mp= new Map();
        new Thread(){
            public void run(){
                while(true){
                    repaint();
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    if(mario.restrat==true)
                    {
                        mario.totalx-=mario.x;
                        mario.x=0;
                        mario.isGravity=false;
                        mario.y=358;
                        mario.restrat=false;
                        mario.xspeed=5;

                    }
                }
            }
        }.start();
        map=mp.readMap();
        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[0].length; j++ ) {
                if(map[i][j]==1){
                    Block = new Block(j*30,i*30,30,30,new ImageIcon("image/block1.png").getImage());
                    eneryList.add(Block);
                }
                if(map[i][j]==2){
                    pipe = new Pipe(j*30,i*30,60,120,new ImageIcon("image/tube.png").getImage());
                    eneryList.add(pipe);
                }
                if(map[i][j]==4){
                     Block=new  Block(j*30,i*30,60,120,new ImageIcon("image/End.png").getImage());
                    eneryList.add( Block);
                }
                if(map[i][j]==3){
                    Block=new  Block(j*30,i*30,60,120,new ImageIcon("image/ground.png").getImage());
                    eneryList.add(Block);
                }
                if(map[i][j]==5){
                    Block=new  Block(j*30,i*30,60,120,new ImageIcon("image/ground1.png").getImage());
                    eneryList.add(Block);
                }
            }
        }
    }
    public void initFrame(){
        this.setSize(800,450);
        this.setTitle("²�檩Mario");
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(3);
        this.setVisible(true);
        KeyListener kl = new KeyListener(this);
        this.addKeyListener(kl);
    }
    public void paint(Graphics g) {
        BufferedImage bi =(BufferedImage)this.createImage(this.getSize().width,this.getSize().height);
        Graphics big =bi.getGraphics();
        for (int i = 0; i <eneryList.size(); i++ ) {
            Enery e =eneryList.get(i);
            big.drawImage(e.img, e.x, e.y, e.width, e.height,null);
        }
        if(mario.y>=430)
        {
            GameOver Gam= new GameOver(mario.x-400,-200,800,800,new ImageIcon("image/GameOver.png").getImage());
            big.drawImage(Gam.img,Gam.x ,Gam.y,Gam.width,Gam.height,null);
            mario.xspeed=0;
        }
        if(mario.totalx>=49*30-1)
        {
            GameOver Gam= new GameOver(mario.x-400,-200,800,800,new ImageIcon("image/Win.png").getImage());
            big.drawImage(Gam.img,Gam.x ,Gam.y,Gam.width,Gam.height,null);
            mario.xspeed=0;
        }
        big.drawImage(mario.img, mario.x, mario.y, mario.width, mario.height,null);
        g.drawImage(bi,0,0,null);
    }
}