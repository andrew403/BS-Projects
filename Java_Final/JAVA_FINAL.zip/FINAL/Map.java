package Util;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.ArrayList;
public class Map {
    public ArrayList<String> list = new ArrayList<String>();
    public int [][] map=null;

    public  int[][] readMap() throws Exception {
        FileInputStream fis = new FileInputStream("image/map.txt");
        InputStreamReader isr = new InputStreamReader(fis);
        BufferedReader br = new BufferedReader(isr);
        String value =br.readLine();
        while(value!=null){
            list.add(value);
            value =br.readLine();
        }
        br.close();
        int row=list.size();
        int cloum=0;
        for (int i = 0; i < 1; i++) {
            String str=list.get(i);
            String [] values=str.split(",");
            cloum=values.length;
        }
        map = new int [row][cloum];
        for (int i = 0; i < list.size(); i++) {
            String str=list.get(i);
            String [] values=str.split(",");
            for (int j = 0; j < values.length; j++) {
                map[i][j]=Integer.parseInt(values[j]);
            }
        }
        return map;
    }
}