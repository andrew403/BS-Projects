package com.huaxin.enery;
import java.awt.Image;
public class Pipe extends Enery {
    public Pipe(int x, int y, int width, int height, Image img) {
        super(x, y, width, height, img);
    }
}