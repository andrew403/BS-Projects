package com.huaxin.enery;
import java.awt.Image;
public class Win  extends  Enery{
    public Win(int x, int y, int width, int height, Image img) {
        super(x, y, width, height, img);
    }
}
