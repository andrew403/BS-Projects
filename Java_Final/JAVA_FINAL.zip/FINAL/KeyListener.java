package com.huaxin.mario;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
public class KeyListener extends KeyAdapter{
    public GameFrame gf;
    public boolean jumpFlag=true;
    public KeyListener(GameFrame gf) {
        this.gf=gf;
    }
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        switch(code){
            case 39:
                gf.mario.right=true;
                break;
            case 37:
                gf.mario.left=true;
                break;
            case 74:
                gf.mario.up=true;
                break;
            case 82:
                gf.mario.restrat=true;
                break;
        }
    }

    public void keyReleased(KeyEvent e) {
        int code=e.getKeyCode();
        if(code==39){
            gf.mario.right=false;
            gf.mario.img=new ImageIcon("image/main2.png").getImage();
        }
        if(code==37){
            gf.mario.left=false;
            gf.mario.img=new ImageIcon("image/main2.png").getImage();
        }
        if(code==74){
            gf.mario.up=false;
        }
    }
}