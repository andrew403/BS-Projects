package com.huaxin.mario;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;
import java.awt.Image;
import com.huaxin.enery.Enery;
import Util.Map;
import java.awt.Graphics;
import com.huaxin.enery.Win;
import com.huaxin.enery.GameOver;
public class Mario extends Thread{
    public GameFrame gf;
    public int totalx;
    public Enery Win,GameOver;
    public boolean jumpFlag=true;
    public int x=0,y=358;
    public int xspeed=5,yspeed=1;
    public int width=30,height=32;
    public Image img = new ImageIcon("image/main1.png").getImage();
    public boolean left=false,right=false,down=false,up=false,restrat=false;
    public String Dir_Up="Up",Dir_Left="Left",Dir_Right="Right",Dir_Down="Down";
    public Mario (GameFrame gf) {
        this.gf=gf;
        this.Gravity();
    }
    public int [][] map =null;

    public void run(){
        Map mp = new Map();
        try {
            map=mp.readMap();
        } catch (Exception e) {
            e.printStackTrace();
        }
        while(true){
            if(left){
                totalx-=this.xspeed;
                if(hit(Dir_Left)){
                    this.xspeed=0;
                }
                if(this.x>=0){
                    this.x-=this.xspeed;
                    this.img=new ImageIcon("image/main2.png").getImage();
                }
                this.xspeed=5;
            }
            if(right){
                totalx+=this.xspeed;
                if(hit(Dir_Right)){
                    this.xspeed=0;
                }
                if(this.x<400){
                    this.x+=this.xspeed;
                    this.img=new ImageIcon("image/main2.png").getImage();
                }
                if(this.x>=400){
                    for (int i = 0; i <gf.eneryList.size(); i++ ) {
                        Enery enery = gf.eneryList.get(i);
                        enery.x-=this.xspeed;
                    }
                    this.img=new ImageIcon("image/main2.png").getImage();
                }
                this.xspeed=5;
            }
            if(up){
                if(jumpFlag && !isGravity){
                    jumpFlag=false;
                    new Thread(){
                        public void run(){
                            jump();
                            jumpFlag=true;
                        }
                    }.start();
                }
            }

            try {
                this.sleep(20);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    public void jump(){
        int jumpHeigh=0;
        for (int i = 0; i < 150; i++) {
            gf.mario.y-=this.yspeed;
            jumpHeigh++;
            if(hit(Dir_Up)){
                break;
            }
            try {
                Thread.sleep(5);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        for (int i = 0; i <jumpHeigh; i++ ) {
            gf.mario.y+=this.yspeed;
            if(hit(Dir_Down)){
                this.yspeed=0;
            }
            try {
                Thread.sleep(5);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        this.yspeed=1;
    }

    public boolean hit(String dir){

        Rectangle myrect = new Rectangle(this.x,this.y,this.width,this.height);
        Rectangle rect =null;
        for (int i = 0; i < gf.eneryList.size(); i++) {
            Enery enery = gf.eneryList.get(i);
            if(dir.equals("Left")){
                rect = new Rectangle(enery.x+2,enery.y,enery.width,enery.height);
            }
            else if(dir.equals("Right")){
                rect = new Rectangle(enery.x-2,enery.y,enery.width,enery.height);
            }
            else if(dir.equals("Up")){
                rect = new Rectangle(enery.x,enery.y+1,enery.width,enery.height);
            }else if(dir.equals("Down")){
                     rect = new Rectangle(enery.x,enery.y-2,enery.width,enery.height);
            }
            if(myrect.intersects(rect)) {
                return true;
            }
        }
        return false;
    }
    public boolean isGravity=false;
    public void Gravity(){
        new Thread(){
            public void run(){
                while(true){
                    try {
                        sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    if(!jumpFlag){
                    }
                    while(true){
                        if(!jumpFlag){
                            break;
                        }
                        if(hit(Dir_Down)){
                            if(map[y/(358/13)][x/30]!=0)
                                isGravity=false;
                            break;
                        }
                        if(y>=358&&map[y/(358/13)][x/30]!=0){
                            isGravity=false;
                        }
                        else{
                            isGravity=true;
                            y+=yspeed;
                        }
                        try {
                            sleep(10);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }.start();
    }
}