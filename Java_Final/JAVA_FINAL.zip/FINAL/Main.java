package com.huaxin.mario;

public class Main {
    public static void main(String[] args) throws Exception {
        GameFrame gf = new GameFrame();
        gf.initFrame();
    }
}